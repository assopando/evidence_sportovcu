<?php


class ArchivKontroler extends Kontroler
{
    public function zpracuj($parametry)
    {


        $idTentoArchiv = $_GET['iar'];

        $modelAkce = new ModelyAkce;
        $modelAkcedisc = new ModelyAkce_disc;
        $modelDisciplin = new ModelyDisciplina;
        $modelUzivatel = new ModelyUzivatel();
        $modelSoupiska = new ModelySoupiska();


        $archiv = $modelAkce->vratVsechnyAkce();
        $soupiska = $modelSoupiska->vratVsechnySoupisky();

        foreach ($archiv as $ar) {

            if ($idTentoArchiv == $ar["id_akce"]) {
                $konkretniarchiv = [
                    'id_akce' => $ar["id_akce"],
                    'nazev_akce' => $ar['nazev_akce'],
                    'datum_zahajeni' => $ar['datum_zahajeni'],
                    'datum_konce' => $ar['datum_konce'],
                    'misto_kon' => $ar['misto_kon'],
                    'popisek_akce' => $ar['popisek_akce'],
                    'pritomni_uc' => $ar['pritomni_uc'],
                    'shrnuti' =>$ar['shrnuti'],

                ];
            }
        }

        foreach ($soupiska as $soup) {
            $konkretnisoupiska=null;
            if ($idTentoArchiv == $soup["id_akce"]) {
                $konkretnisoupiska = [
                    'id_soup' => $soup["id_soup"],
                    'id_akce' => $soup['id_akce'],
                    'nazev_skupiny' => $soup['nazev_skupiny'],
                    'vys_s' => $soup['vys_s'],
                    


                ];
            }
        }

//Edit ---------------------------------------------------------------------------------------------------------------


        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Byl odeslán formulář

            $archivovano=1;

            if (isset($_POST['archivovat'])) {
                // Zpracování uložení
                $hodnotyAkce= [
                    'pritomni_uc' => $_POST['pritomni_uc'],
                    'archivovano' => $archivovano,
                    'shrnuti' => $_POST['shrnuti'],
                    
                    // Další potřebné údaje
                ];

                $editAkce= $modelAkce->zmenAkci($hodnotyAkce, $idTentoArchiv);

                $hodnotySoupisky= [
                    'vys_s' => $_POST['vys_s'],
                ];

                $editSoupiska = $modelSoupiska->zmenSoupisku($hodnotySoupisky,$idTentoArchiv);


                if($editSoupiska == 1 && $editAkce == 1){
                    $this->pridejZpravu("Záznamu byl úspěšně archivován.");
                    $this->pohled="vypisakci";
                }
                else{
                    $this->pridejZpravu("Záznamu nebyl archivován");
                }
            }







        }


        $this->data["konkretniarchiv"] = $konkretniarchiv;

        
        
            $this->data["konkretnisoupiska"] = $konkretnisoupiska;
        
        
        

        $akcedisc = $modelAkcedisc->vratVsechnyAkce_disc();
        $this->data["akcedisc"] = $akcedisc;

        $disc = $modelDisciplin->vratVsechnyDiscipliny();
        $this->data["disc"] = $disc;

        $this->data["ucitele"] = $modelUzivatel->vratInfoVsechUcitelu();


        $this->pohled = "archiv";
    }
}
