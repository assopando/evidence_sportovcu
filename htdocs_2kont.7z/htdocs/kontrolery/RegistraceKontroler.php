<?php
class RegistraceKontroler extends Kontroler {
    public function zpracuj($parametry) {

        $this->pohled = "registrace";
    }
}