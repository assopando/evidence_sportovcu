<?php
class ChybaKontroler extends Kontroler {
    public function zpracuj($parametry) {
        $this->pohled = "chyba";
    }
}