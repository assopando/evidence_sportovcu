<?php

 class LdapKontroler extends Kontroler {
    public function zpracuj($parametry)
    {
        
        
        

        $this->pohled="ldap";
    }
 }


?>
